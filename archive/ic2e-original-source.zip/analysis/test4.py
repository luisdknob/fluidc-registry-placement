import json
from networkx.readwrite import json_graph
import pandas as pd
import matplotlib.pyplot as pyplot

color = ["blue", "red", "grey", "green"]
marker = ["x","D"]
label = ["1 Registry - FluidC", "1 Registry - Random","2 Registries - FluidC", "2 Registries - Random","4 Registries - FluidC", "4 Registries - Random", "8 Registries - FluidC", "8 Registries - Random"]
#label = ["2 Registries - FluidC", "4 Registries - FluidC", "8 Registries - FluidC"]
fig,ax = pyplot.subplots(figsize=(8,6))

for idy, band in enumerate(["9","10","1", "2", "3", "4", "6", "8"]):
    json_file =  open("random_deadtime_600_random_1hour-container_time_"+band+".json", "r")

    load = json.load(json_file)

    df = pd.json_normalize(load["containers"])

    df = df[df.downloaded != 2]

    stats_df = df \
        .groupby('download_time') \
        ['download_time'] \
        .agg('count') \
        .pipe(pd.DataFrame) \
        .rename(columns = {'download_time': 'frequency'})

    #PDF
    stats_df['pdf'] = stats_df['frequency'] / sum(stats_df['frequency'])

    #CDF
    stats_df['cdf'] = stats_df['pdf'].cumsum()
    stats_df = stats_df.reset_index()

    #print(stats_df)

    if idy == 0:
        markercount = 700
    else:
        markercount = 500

    ax.plot(stats_df['download_time'], stats_df['cdf'], label=label[idy], color=color[idy//2], marker=marker[idy%2],markevery=markercount,  markersize=4, linewidth=0.5)

# Function x**(1/2)
def forward(x):
    return x**(1/2)


def inverse(x):
    return x**2

ax.set_ylim(0.0,1.0)
ax.set_xlim(0,160)
ax.set_yticks([0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0])
ax.set_xticks([0,20,40,60,80,100,120,140,160])
#ax.set_xticks([0,50,100,150,200,250,300,350,400,450,500])
#ax.set_xticks([0,100,200,300,400,500,600,700,800,900,1000])
#ax.set_xscale('function', functions=(forward, inverse))
ax.set_ylabel("Percentage of Containers (CDF)")
ax.set_xlabel("Instantiation Time (s)")
#ax.set_title("GARR Topology - PESS Scheduler")
ax.grid()
ax.legend().set_visible(True)
pyplot.savefig("cdf_bd_usage_vc.png", transparent=True)
