import sys
import json
import re
from uuid import uuid1 as uuid

with open(sys.argv[1], 'r') as file:

    i = 0

    rounds = []
    arrival_time = 0
    chains = []
    chain = []
    app = []
    break_line = False
    start_chain = False

    baseline = 0
    delete = False

    load = 0.0

    for line in file:
        #print(line)
        if line.find("ARRIVAL TIME:") == 0:
            break_line = False
            arrival_time = float(line[13:])
            if len(chains):
                app.append(chains)
                chains = []
            if len(app):
                rounds.append(app)
                app = []
            else:
                rounds.append({})
        elif line.find("SERVICE INDEX:") == 0:
            delete = False
        elif line.find("DELETED CHAINS HEURISTIC:") == 0:
            delete = True
        elif line.find("-----------------------") == 0:
            if start_chain:
                start_chain = False
                if len(chain):
                    chains.append(chain)
                    chain = []
            if break_line == True:
                if len(chains):
                    app.append(chains)
                    chains = []
            break_line = True
        elif line.find("Chain") == 0:
            break_line = False
            start_chain = True
        elif line.find("HEURISTIC") == 0:
            baseline = 1
        elif line.find("BASELINE") == 0:
            baseline = 0
        else:
            if delete == True and line.find("Service_#") == 0:
                num = int(re.split("#|:", line)[1])
                for var1 in rounds[num]:
                    for var2 in var1:
                        for var3 in var2:
                            var3["deadline"] = arrival_time
            elif line.find("[") is not -1 or line.find("Consumed") is not -1 or baseline == 0:
                break_line = False
            elif line.find("Objective") is not -1:
                values = line.rstrip().split(" ")
                load+=float(values[3])
            elif start_chain:
                break_line = False
                values = line.rstrip().split(" ")
                chain.append({"name":values[0], "arrival_time":arrival_time, "node":values[1]})
    
if len(app) > 0:
    rounds.append(app)

rounds = rounds[1:]

#print(rounds)

print("rounds: %d" % len(rounds))

num_services = 0
num_chains = 0
num_containers = 0
container_name = []
containers = []
for round in rounds:
    num_services+=len(round)
    for services in round:
        num_chains+=len(services)
        for chains in services:
            chain_id = uuid().int
            num_containers+=len(chains)
            for chain in chains:
                if chain['name'] not in container_name:
                    container_name.append(chain['name'])
                if chain['name'] not in ["app", "remote"]:
                    chain['chain'] = chain_id   
                    containers.append(chain)

print("services: %d" % num_services)
print("chains: %d" % num_chains)
print("containers: %d" % num_containers)
print("containers clean: %d" % len(containers))
#print(containers)
print("number of apps: %d " % len(container_name))
print(container_name)
#print("objective total value: %.4f" % load)
#print(rounds[:1])

with open("tmp.json", "w") as file:
    file.write("{\"schedule\":[\n")
    for container in containers:
        file.write(json.dumps(container)+",\n")
    file.write("]\n}")
